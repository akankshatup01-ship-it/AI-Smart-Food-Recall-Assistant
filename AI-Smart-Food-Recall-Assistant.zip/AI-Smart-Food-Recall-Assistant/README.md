# AI Smart Food Recall Assistant

An AI-powered food recall investigation assistant using a FastAPI backend, Gemini File Search/RAG, the FDA Food Enforcement API, and a web frontend.

## Project Structure

```text
AI-Smart-Food-Recall-Assistant/
├── backend/
│   ├── main.py
│   ├── setup_rag.py
│   ├── test_gemini.py
│   ├── knowledge_base.txt
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── script.js
│   └── style.css
├── .env.example
├── .gitignore
├── .gitattributes
└── README.md
```

## Technologies

- Python
- FastAPI
- Uvicorn
- Gemini API / Gemini File Search
- RAG (Retrieval-Augmented Generation)
- FDA Food Enforcement API
- HTML, CSS and JavaScript

## Environment Variables

Create a `.env` file in the `backend` directory using `.env.example` as a reference:

```env
FDA_API_KEY=your_fda_api_key
GEMINI_API_KEY=your_gemini_api_key
GEMINI_FILE_SEARCH_STORE=your_gemini_file_search_store
```

**Do not upload `.env` or API keys to GitHub.**

## Installation

Open a terminal in the `backend` folder:

```bash
pip install -r requirements.txt
```

## RAG Knowledge Base Setup

After configuring the Gemini API key, run:

```bash
python setup_rag.py
```

The script creates the Gemini File Search store and uploads the knowledge base. Use the resulting store name for `GEMINI_FILE_SEARCH_STORE`.

## Run the Backend

From the `backend` folder:

```bash
uvicorn main:app --reload
```

The FastAPI application serves the frontend and provides the recall-search and RAG endpoints used by the web interface.

## Main Features

- Search food recall information through the FDA Food Enforcement API.
- Ask general food-recall questions using the RAG knowledge base.
- Ask recall-specific questions using retrieved recall records and the knowledge base.
- Provide AI-generated informational guidance while keeping human review in the decision process.

## Important

The AI responses are informational. They should not replace official FDA information, regulatory requirements, food-safety procedures, or human decision-making.
